/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package designchallenge2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Mart
 */
public class CalendarController {
    CalendarProgramView calP;
    CalendarModel cm;
    EventView eview;
    TodoListView tlv = new TodoListView();
    public CalendarController(CalendarModel cm){
        this.calP = new CalendarProgramView(cm, this);
        this.eview = new EventView();
        this.tlv = new TodoListView();
        this.cm = cm;
        this.eview=eview;


        this.calP.addBtnPrevActionListener(new btnPrev_Action());
	this.calP.addBtnNextActionListener(new btnNext_Action());
	this.calP.addCmbYearActionListener(new cmbYear_Action());
        this.calP.addEventBtnActionListener(new eventBtn_Action());
        this.eview.SubmitListener(new  SubmitListen());
        this.eview.CSVListener(new CSVListen());
        this.eview.PSVListener(new PSVListen());
                                                  
        
        this.cm.attachModelListener(calP);
        
        calP.refreshCalendar(cm.monthToday, cm.yearToday);
        tlv.setVisible(true);
    }
    
    
    class btnPrev_Action implements ActionListener
        {
		public void actionPerformed (ActionEvent e)
                {
			if (cm.monthToday == 0)
                        {
				cm.monthToday = 11;
				cm.yearToday -= 1;
			}
			else
                        {
				cm.monthToday -= 1;
			}
			calP.refresh();
		}
	}
    
    public void NextMonth(){
        if (cm.monthToday == 11)
                        {
				cm.monthToday = 0;
				cm.yearToday += 1;
			}
			else
                        {
				cm.monthToday += 1;
			}
    }
    
	class btnNext_Action implements ActionListener
        {
		public void actionPerformed (ActionEvent e)
                {
			if (cm.monthToday == 11)
                        {
				cm.monthToday = 0;
				cm.yearToday += 1;
			}
			else
                        {
				cm.monthToday += 1;
			}
			calP.refresh();
		}
	}
        
    public void setYearToday(int year){
        cm.yearToday = year;
    }
    
	class cmbYear_Action implements ActionListener
        {
		public void actionPerformed (ActionEvent e)
                {
			if (calP.cmbYear.getSelectedItem() != null)
                        {
				String b = calP.cmbYear.getSelectedItem().toString();
				cm.yearToday = Integer.parseInt(b);
				calP.refresh();
			}
		}
	}
        class eventBtn_Action implements ActionListener{
            
            public void actionPerformed (ActionEvent e){
                eview.setVisible(true);
               
            }
        }
        class CSVListen implements ActionListener{
            
            public void actionPerformed (ActionEvent e){
                String csv = eview.getCSV();
               cm.cdp.readData(csv);
               cm.CSVreaderToModel(cm.cdp.getEvents());
            }
        }
        class PSVListen implements ActionListener{
            
            public void actionPerformed (ActionEvent e){
                String psv = eview.getPSV();
               cm.pdp.readData(psv);
               cm.PSVreaderToModel(cm.cdp.getEvents());
            }
        }
        
        class SubmitListen implements ActionListener{
        /**
         * does the action
         * @param e contains the action performed
         */
            
            @Override
            public void actionPerformed(ActionEvent e) {
                int possible=0;
                if(eview.getDMonth().equals("2")){//feb 28 and 29 if leap year
                    if(calP.getDYear()%4==0 && Integer.parseInt(eview.getDDay())<=29)
                        possible=1;
                    else if( Integer.parseInt(eview.getDDay())<=28)
                        possible=1;
                    else
                        possible=0;
                    
                }else if(eview.getDMonth().equals("4")||eview.getDMonth().equals("6")||eview.getDMonth().equals("9")||eview.getDMonth().equals("11")){//30 day months
                    if(Integer.parseInt(eview.getDDay())<=30)
                        possible=1;
                    else
                        possible=0;
                }else//31 day months
                        possible=1;
                if(possible==1){
                cm.addNewEvent(new Event(eview.getDName(), eview.getColor(), eview.getDMonth(), eview.getDDay(), Integer.toString(calP.getDYear())));//add error handling for impoosible dates in the future
                //add newevent to some array list
                cm.dw.writeData(cm.getEventList());                                //writes to Event List.csv
                
                eview.reset();
                eview.setVisible(false);//only use it if date is actaully useable
                }else
                    eview.errorWarn("Specified Date is unusable");
                
                calP.refresh();
            }
    }
}
