/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package designchallenge2;

/**
 *
 * @author Ashen One
 */
abstract public class Plan {
    private final String name;
    private final String color;           
    private final String month;
    private final String day;
    private final String year;
   // private final int timeStart;                    //idk how to get time
    
    public Plan(String name, String color, String month, String day, String year){
        this.name = name;
        this.color = color;
        this.month = month;
        this.day = day;
        this.year = year;
        //this.timeStart = timeStart;
    }
    
    public String getName(){
        return name;
    }
    
    public String getColor(){
        return color;
    }
    
    public String getMonth(){
        return month;
    }
    
    public String getDay(){
        return day;
    }
    
    public String getYear(){
        return year;
    }
}
