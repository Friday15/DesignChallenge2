/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package designchallenge2;

/**
 *
 * @author Ashen One
 */
public class Task extends Plan{
    private boolean done;
    
    public Task(String name, String color, String month, String day, String year){
        super(name, color, month, day, year);
        done = false;
    }
    
    public boolean getDone(){
        return done;
    }
    
    public void checkDone(){
        done = true;
    }
}
