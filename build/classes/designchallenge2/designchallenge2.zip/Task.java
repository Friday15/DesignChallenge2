/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package designchallenge2;

import java.util.Date;

/**
 *
 * @author Ashen One
 */
public class Task extends Plan{
    
    public Task(String name, Date s,Boolean d){
        super(name, s, d);
    }
    
}
